from flask import Flask, render_template, request
import numpy as np
import pickle

app = Flask(__name__)

# Load the trained model and scaler
model = pickle.load(open('heart_disease_model.pkl', 'rb'))
scaler = pickle.load(open('scaler.pkl', 'rb'))

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    input_data = [
        int(request.form['Age']),
        int(request.form['Sex']),
        int(request.form['ChestPain']),
        int(request.form['RestBP']),
        int(request.form['Chol']),
        int(request.form['Fbs']),
        int(request.form['RestECG']),
        int(request.form['MaxHR']),
        int(request.form['ExAng']),
        float(request.form['Oldpeak']),
        int(request.form['Slope']),
        int(request.form['Ca']),
        int(request.form['Thal']),
    ]

    input_array = np.asarray(input_data).reshape(1, -1)
    input_scaled = scaler.transform(input_array)
    prediction = model.predict(input_scaled)

    result = 'Person has Heart Disease' if prediction[0] == 1 else 'Person does NOT have Heart Disease'
    return render_template('index.html', prediction_text=result)

if __name__ == "__main__":
    app.run(debug=True)

